boats = "Boats"
loads = "Loads"
#url = "http://127.0.0.1:8080"
url = "https://elsomr-final.appspot.com"